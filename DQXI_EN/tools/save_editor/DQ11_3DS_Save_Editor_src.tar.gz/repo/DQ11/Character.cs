﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace DQ11
{
	class Character : INotifyPropertyChanged
	{
		private readonly uint mBaseAddress;

		public event PropertyChangedEventHandler PropertyChanged;

		// Noms d'origine japonais -> clé i18n (Char_*). Table d'AFFICHAGE uniquement,
		// jamais écrite dans la save. Point d'extension : ajouter ici les invités
		// (ハンフリー, ルキ, ルコ, エッケンハルト, ...) avec leur clé Char_*,
		// puis déclarer la clé dans les trois Strings.*.xaml.
		private static readonly Dictionary<string, string> mDisplayNameKeys =
			new Dictionary<string, string>
		{
			{ "カミュ",     "Char_Erik" },
			{ "ベロニカ",   "Char_Veronica" },
			{ "セーニャ",   "Char_Serena" },
			{ "シルビア",   "Char_Sylvando" },
			{ "ロウ",       "Char_Rab" },
			{ "マルティナ", "Char_Jade" },
			{ "グレイグ",   "Char_Hendrik" },
			{ "ルキ",       "Char_Sandy" },
			{ "エマ",       "Char_Emma" },
			{ "ルコ",       "Char_Connie" },
			{ "ハンフリー",  "Char_VinceVanquish" },
			{ "謎の青年",    "Char_MysteriousGuy" },
			{ "エッケハルト","Char_Snorri" },
			{ "犬",         "Char_Dog" },
			{ "キナイ",     "Char_Kainui" },
			{ "バハトラ",   "Char_Da" },
			{ "チェロン",   "Char_Son" },
			{ "テバ",       "Char_Atsuo" },
			{ "サンポ",     "Char_Lama" },
			{ "アーウィン", "Char_KingIrwin" },
			{ "クルッチ",   "Char_Ickle" },
		};

		public ObservableCollection<CharItem> Item { get; set; } = new ObservableCollection<CharItem>();
		public List<CharStatus> Status { get; set; } = new List<CharStatus>();

		public Character(uint address)
		{
			mBaseAddress = address;
			for(uint i = 0; i < 24; i++)
			{
				Item.Add(new CharItem(mBaseAddress + 0x24 + i * 2));
			}

			Status.Add(new CharStatus(mBaseAddress + 0x12, 7, "St_Zone"));
			Status.Add(new CharStatus(mBaseAddress + 0x12, 1, "St_Poison"));
			Status.Add(new CharStatus(mBaseAddress + 0x12, 2, "St_Curse"));
			Status.Add(new CharStatus(mBaseAddress + 0x12, 3, "St_Curse2"));
			Status.Add(new CharStatus(mBaseAddress + 0x12, 4, "St_Death"));
		}

		// Le nom est stocké en DEUX morceaux depuis le patch « noms longs » :
		//   +0x02 : 7 emplacements UTF-16 (14 octets), zone d'origine du jeu ;
		//   +0x18 : 2 emplacements UTF-16 (4 octets), zone laissée inutilisée par
		//           le jeu d'origine et réaffectée au nom par le patch.
		// Soit 9 emplacements = 8 caractères + le zéro terminal.
		private const uint NameAddress1 = 0x02;
		private const uint NameSize1 = 14;
		private const uint NameAddress2 = 0x18;
		private const uint NameSize2 = 4;

		/// <summary>Nombre de caractères stockables, hors zéro terminal.</summary>
		public const int NameMaxLength = 8;

		/// <summary>Au-delà, le nom n'est lisible qu'avec le patch « noms longs ».</summary>
		public const int NameSafeLength = 6;

		public String Name
		{
			get
			{
				SaveData data = SaveData.Instance();
				String raw = data.ReadUnicode(mBaseAddress + NameAddress1, NameSize1)
					+ data.ReadUnicode(mBaseAddress + NameAddress2, NameSize2);
				// Filet de sécurité : coupe sur un éventuel zéro interne (données
				// malformées), ReadUnicode n'élaguant que les zéros de bordure.
				int end = raw.IndexOf((char)0);
				return end < 0 ? raw : raw.Substring(0, end);
			}
			set
			{
				String name = value ?? "";
				if (name.Length > NameMaxLength) name = name.Substring(0, NameMaxLength);

				// WriteUnicode complète de zéros jusqu'à la taille demandée : le zéro
				// terminal est donc écrit d'office et les résidus d'un nom précédent
				// plus long sont effacés dans les deux zones.
				int split = (int)NameSize1 / 2;   // 7 caractères dans la première zone
				SaveData data = SaveData.Instance();
				data.WriteUnicode(mBaseAddress + NameAddress1, NameSize1,
					name.Length > split ? name.Substring(0, split) : name);
				data.WriteUnicode(mBaseAddress + NameAddress2, NameSize2,
					name.Length > split ? name.Substring(split) : "");

				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("DisplayName"));
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("NameTooLong"));
			}
		}

		/// <summary>
		/// Vrai quand le nom dépasse les 6 caractères du jeu non patché : l'onglet
		/// Character affiche alors un pictogramme d'avertissement.
		/// </summary>
		public bool NameTooLong
		{
			get { return Name.Length > NameSafeLength; }
		}

		/// <summary>
		/// Nom d'AFFICHAGE traduit (lecture seule). Si le nom brut de la save est
		/// un nom d'origine connu, renvoie sa traduction selon la langue active ;
		/// sinon (héros, nom déjà édité) renvoie le nom brut tel quel.
		/// N'écrit jamais dans la save.
		/// </summary>
		public String DisplayName
		{
			get
			{
				string raw = Name;
				string key;
				if (raw != null && mDisplayNameKeys.TryGetValue(raw, out key))
				{
					return LocalizationManager.Get(key);
				}
				return raw;
			}
		}

		/// <summary>Notifie l'UI que DisplayName a pu changer (bascule de langue).</summary>
		public void RefreshDisplayName()
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("DisplayName"));
		}

		public uint Lv
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x10, 1);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x10, 1, value, 1, 99);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Lv"));
			}
		}

		public uint Exp
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x14, 4);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x14, 4, value, 0, 9999999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Exp"));
			}
		}

		public uint HP
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x20, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x20, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("HP"));
			}
		}

		public uint MP
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x22, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x22, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("MP"));
			}
		}

		public uint MaxHP
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x100, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x100, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("MaxHP"));
			}
		}

		public uint MaxMP
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x102, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x102, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("MaxMP"));
			}
		}

		public uint AttackMagic
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x10C, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x10C, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("AttackMagic"));
			}
		}

		public uint HealMagic
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x10E, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x10E, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("HealMagic"));
			}
		}

		public uint Attack
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x104, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x104, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Attack"));
			}
		}

		public uint Diffence
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x10A, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x10A, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Diffence"));
			}
		}

		public uint Speed
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x108, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x108, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Speed"));
			}
		}

		public uint Skillful
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x106, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x106, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Skillful"));
			}
		}

		public uint Charm
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x110, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x110, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Charm"));
			}
		}

		public uint Skill
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x112, 2);
			}
			set
			{
				Util.WriteNumber(mBaseAddress + 0x112, 2, value, 0, 999);
				PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("Skill"));
			}
		}

		public uint Strategy
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x1C, 1);
			}
			set
			{
				SaveData.Instance().WriteNumber(mBaseAddress + 0x1C, 1, value);
			}
		}

		public bool Zone
		{
			get
			{
				return SaveData.Instance().ReadNumber(mBaseAddress + 0x12, 1) == 0x80;
			}
			set
			{
				SaveData.Instance().WriteNumber(mBaseAddress + 0x12, 1, value ? 0x80U : 0);
			}
		}

		public int EquipRightHand
		{
			get
			{
				return Equip(0x54);
			}
			set
			{
				Equip(0x54, value);
			}
		}

		public int EquipLeftHand
		{
			get
			{
				return Equip(0x55);
			}
			set
			{
				Equip(0x55, value);
			}
		}

		public int EquipHead
		{
			get
			{
				return Equip(0x56);
			}
			set
			{
				Equip(0x56, value);
			}
		}

		public int EquipBody
		{
			get
			{
				return Equip(0x57);
			}
			set
			{
				Equip(0x57, value);
			}
		}

		public int EquipAccessory1
		{
			get
			{
				return Equip(0x58);
			}
			set
			{
				Equip(0x58, value);
			}
		}

		public int EquipAccessory2
		{
			get
			{
				return Equip(0x59);
			}
			set
			{
				Equip(0x59, value);
			}
		}

		public void Min()
		{
			Lv = 1;
			Exp = 0;
			HP = 1;
			MP = 0;
			MaxHP = 0;
			MaxMP = 0;
			AttackMagic = 0;
			HealMagic = 0;
			Attack = 0;
			Diffence = 0;
			Speed = 0;
			Skillful = 0;
			Charm = 0;
			Skill = 0;
		}

		public void Max()
		{
			Lv = 99;
			Exp = 9999999;
			HP = 999;
			MP = 999;
			MaxHP = 999;
			MaxMP = 999;
			AttackMagic = 999;
			HealMagic = 999;
			Attack = 999;
			Diffence = 999;
			Speed = 999;
			Skillful = 999;
			Charm = 999;
			Skill = 999;
		}

		private void Equip(uint address, int value)
		{
			if (value == -1) value = 0xFF;
			SaveData.Instance().WriteNumber(mBaseAddress + address, 1, (uint)value);
		}

		private int Equip(uint address)
		{
			int value = (int)SaveData.Instance().ReadNumber(mBaseAddress + address, 1);
			if (value == 0xFF) value = -1;
			return value;
		}
	}
}
