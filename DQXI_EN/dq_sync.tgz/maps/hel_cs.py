# Heliodor cutscenes (a_010_cs_130/140 castle, a_020 dungeon & sewers): (pack, entry, off) -> (src, english)
P='/param/scenario/cs/%s.pack'
M = {}
def add(pack, items):
    for off, src, en in items: M[(P % pack, 'cs_text.bxon', off)] = (src, en)
add('a_010_cs_130', [(0x120,'o',"Halt! Not so fast!"),(0x148,'o',"State your business, traveller!"),
  (0x190,'o',"{var:1} explains that he's the Luminary, and that he's come to speak to the King."),
  (0x208,'o',"Ha ha ha! That's the funniest one I've heard all week! You, the Luminary? Pull the other one!"),
  (0x27c,'o',"Clear off, will you? We haven't got time for this kind of nonsense."),
  (0x2d0,'o',"...What's that? You want to show that pendant to the King, you say?"),
  (0x334,'o',"......... Wait here a minute.")])
add('a_010_cs_140', [(0x28c,'o',"That will be quite close enough. Welcome to Heliodor Castle, friend."),
  (0x2dc,'o',"The Jewel of Dundrasil..."),
  (0x30c,'o',"You are bold indeed to have made your way here alone, wanderer. I am Carnelian, ruler of Heliodor."),
  (0x398,'o',"How long have I waited for this day? And now finally we meet. Truly, it is an honour."),
  (0x454,'o',"That you come here proffering the Jewel and asking to see me suggests you know something of your...true nature."),
  (0x528,'o',"If you truly are the Luminary, then you must also bear the Mark on the back of your hand."),
  (0x5cc,'o',"Yes, the Mark of Light! Then there is no doubt. You are the baby from that day..."),
  (0x668,'o',"Rejoice, dear subjects! The day is upon us at last! The Luminary walks among us once more!"),
  (0x748,'o',"Tell me, O Luminary..."),
  (0x794,'o',"Where exactly is it that you hail from? I would so very much like to pay tribute to those who raised you."),
  (0x838,'o',"{var:1} tells King Carnelian that he was raised in the village of Cobblestone."),
  (0x8c4,'o',"I see... Cobblestone, you say? Jasper, you heard?"),
  (0x930,'o',"I did, my liege. A village of provincial nobodies, deep in the rocky south..."),
  (0x9d4,'o',"Jasper! Then I take it you know what to do. Do not disappoint me."),
  (0xa28,'o',"Yes, my liege!"),
  (0xa38,'o',"Accursed Luminary! I know not why you came here alone, but whatever your wicked scheme, it shall not succeed!"),
  (0xb2c,'o',"Hendrik! Take this harbinger of calamity and cast him into the dungeon!"),
  (0xbc0,'o',"Know this, all of you! The Luminary is the root of all evil in this land!"),
  (0xc6c,'o',"He heralds the resurrection of the Dark One! Just as light is bound to darkness, the Luminary is bound to the Lord of Shadows!"),
  (0xd44,'o',"Did you really think you could fool one as wise as His Majesty? He knows your true nature all too well."),
  (0xe28,'o',"Men! Seize this wretch!")])
add('a_020_cs_010', [(0xa4,'o',"You claim to hail from Cobblestone? Well, before the sun has set three times, we shall know the truth."),
  (0x144,'o',"By then, Jasper will have returned from his...investigation."),
  (0x1ac,'o',"If I were you, Darkspawn, I would not expect to live beyond that day...")])
add('a_020_cs_020', [(0x13c,'o',"Will you quit moping? Most folks they throw in here at least wait a while before going stir-crazy."),
  (0x1b8,'o',"What are you in for, anyhow? You don't end up at the bottom of the dungeon without doing something pretty bad."),
  (0x264,'o',"Huh? What did you say!? You didn't do anything? You just said you're the Luminary? You're serious!?"),
  (0x2f8,'o',"Now that's a surprise! The Luminary has shown up in the cell next to mine? This is crazy..."),
  (0x364,'o',"One plate of delicious gruel for the gentleman in the dungeon suite! Come and get it!"),
  (0x3bc,'o',"Urgh...!"),
  (0x3d0,'o',"So the Luminary shows up right in front of me..."),
  (0x420,'o',"So it's all happening just like the Seer said it would...")])
add('a_020_cs_030', [(0x13c,'o',"Wait here!"),(0x160,'o',"You!? But—! Arrrgh!"),
  (0x190,'o',"Don't worry, I didn't kill him. But he won't be waking up any time soon..."),
  (0x1e4,'o',"Things could get pretty hairy up ahead. You'd better take this."),
  (0x254,'o',"{var:1} takes the sword!"),
  (0x290,'o',"Oh, and I found this in the room over there. I guess it's your stuff, right? Figured I'd grab it while I was at it."),
  (0x34c,'o',"{var:1} receives his lost belongings!"),
  (0x3a0,'o',"Me, I got my trusty dagger back, so now I'm pretty much unstoppable.")])
add('a_020_cs_040', [(0x94,'o',"I spent ages digging this hole, planning to break out today, and you just happen to show up? Heck of a coincidence..."),
  (0x160,'o',"Guess I really was meant to help you out, {var:1}, just like the Seer said."),
  (0x1ec,'o',"Anyway, there'll be time to talk about all that later. In you go!")])
add('a_020_cs_060', [(0x94,'f',"Tch... They've got us surrounded!"),(0xc0,'o',"Seriously!?"),(0xe0,'o',"Waaaaaagh!")])
add('a_020_cs_070', [(0x78,'o',"You okay? Looks like we shook the guards at least...")])
add('a_020_cs_080', [(0x78,'o',"Wait. There's something there...")])
add('a_020_cs_085', [(0x94,'o',"Jump for it, {var:1}!"),(0xc0,'f',"That was close. Surely it can't follow us down h—"),(0x108,'o',"Gah! This thing doesn't give up!")])
add('a_020_cs_090', [(0x120,'o',"Has it gone?"),(0x140,'o',"Phew! That was way too close for comfort! Think we gave it the slip..."),
  (0x188,'o',"What's that thing doing under the castle, anyway? Well, whatever. We should get going."),
  (0x220,'o',"Uh-oh..."),(0x234,'o',"RUUUUUUUUUN!"),
  (0x258,'o',"W-We made it...just. Stick around here much longer and we'll run out of lives."),
  (0x2e0,'o',"There he is! The Darkspawn!")])
add('a_020_cs_095', [(0xcc,'o',"That's the last of him...I hope."),
  (0xf4,'o',"By the way, you can actually fight. Beating a monster like that? Maybe you really are the Luminary..."),
  (0x198,'o',"What was that thing doing under the castle, anyway? Well, whatever. We should get going."),
  (0x230,'o',"There he is! The Darkspawn!")])
add('a_020_cs_110', [(0x104,'o',"Looks like our luck finally ran out..."),(0x11c,'o',"There they are! We've got 'em now!"),
  (0x144,'f',"Dammit! They're already on us!"),
  (0x174,'o',"Listen. If they catch us here, you and me are dead meat."),
  (0x204,'o',"Let's do this, {var:1}. I believe in you. I believe in the Luminary..."),
  (0x278,'f',"Hey, you two! What do you think you're doing!?"),
  (0x2b0,'o',"The name's Erik, by the way. Don't forget it...")])
