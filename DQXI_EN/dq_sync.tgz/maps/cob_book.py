# Cobblestone boundary/sign/notes text: param/region/r001.pack book_ie.bxon
R=('/param/region/r001.pack','book_ie.bxon')
M = {}
for off, src, en in [
 (0x8ec,'f',"East: Cobblestone Falls →\nBeyond the falls: Heliodor Shrine"),
 (0x7db0,'f',"East: Cobblestone Falls →\nBeyond the falls: Heliodor Shrine"),
 (0x2884,'o',"Hold on, {var:1}, we can't call it a day yet! We've got to get up to the top and do the ceremony!"),
 (0x2994,'o',"Where are you going now, {var:1}? The ceremony's over! Everyone'll be waiting for us!"),
 (0x2a88,'o',"You don't want to go wandering around out there, {var:1}—you'll end up as a monster's dinner! Head home."),
 (0x2b98,'o',"Oi, where d'you fink you're goin', {var:1}? Yer mum's waitin' for ya! I'd 'ead 'ome sharpish!"),
 (0x2c68,'o',"Oi! Where do ya fink yer goin', {var:1}? Everyone's waitin' for ya up at the north entrance!"),
 (0x2d58,'o',"Oh-ho! Hold on! I wouldn't go through here. The monsters up that way'll make mincemeat of you!"),
 (0x2de0,'o',"If it's Heliodor you're trying to get to, you need to head north, anyway."),
 (0x2ee8,'o',"W-Wait, {var:1}!"),
 (0x2f1c,'o',"Don't go near the Manglegrove! The monsters in there will have your guts for garters! Head straight for Heliodor."),
 (0x3078,'o',"Hang about—you shouldn't go any further. The monsters up there are a proper nasty bunch."),
 (0x3110,'o',"You'll be wanting to go north if you're heading for Heliodor. Mind how you go now!"),
 (0x63ec,'o',"A curious power emanates from the root wrapped around the tree..."),
 (0x6710,'o',"Oi, where d'you fink you're goin', {var:1}? It's too late for fishin', sunshine! Save it till the mornin'!"),
 (0x6814,'o',"A little walk to clear your head's all well and good, {var:1}, but not outside the village. Mind the monsters."),
 (0x691c,'f',"North: Kingdom of Heliodor"),
 (0x6d08,'f',"It's a notebook titled \"Dunstan's Book of Puns.\""),
 (0x6d40,'f',"Incredible! The puns just keep coming!\nI've never been so inspired!"),
 (0x6db0,'f',"I tried diving off the Tor!\nWhat a rocky experience!"),
 (0x6e08,'f',"No, I'm not done yet!\nI simply can't stop!\nThis is a revelation from the heavens!"),
 (0x6e78,'f',"Gemma, have you put on weight?\nI'd never dare say that—it's too heavy a topic!"),
 (0x6ed0,'f',"It's coming! It's coming! The god of puns\nhas descended upon me at last!\nI must tell Gemma straight away!"),
 (0x6fb8,'o',"The door is locked."),
 (0x703c,'f',"The cliff below is all jagged rocks.\nYou can't go any further this way."),
 (0x7120,'f',"Humble folk of Cobblestone,\nGreat Land Spirit's hearth and home"),
 (0x7184,'f',"O Spirit of the Land,\nfor every blessing you bestow on Cobblestone,\nwe give thanks"),
 (0x7e7c,'f',"Ahead: the summit of the Tor\nClimb the cliff to proceed\nStay alert to the very end"),
]:
    M[R + (off,)] = (src, en)
