# condensed versions (3-line window limit verified in-game: a 4th line is never shown)
T = {
"{var:1}, seeing you and my dear Gemma all set for your big day makes me proud as anything—both as a mayor and as a grandfather.":
"{var:1}, seeing you and my dear Gemma all set for your big day makes me proud—as mayor and as grandfather!",
"You're not kids any more, you know—no, you're grown-up now, and that means going to the Tor and offering your thanks.":
"You're not kids any more—you're grown-up now, and that means going up the Tor to offer your thanks.",
"Now, off you go. Head up to the top, give praise to the Spirit of the Land, then come back and tell us how you like the view!":
"Head up to the top, give praise to the Spirit of the Land, then come back and tell me what you saw!",
"Oh, and if you're ever unsure what to do next, press X and select Talk. Gemma might have some useful tips for you!":
"If you're ever unsure what to do, press X and select Talk. Gemma might have some useful tips!",
"Not that I'm complaining, of course. You're always welcome to come home and rest up! Go on, then—off to bed with you!":
"Not that I'm complaining. You're always welcome home for a rest! Go on, then—off to bed with you!",
"To think you and Gemma are all grown-up already! Seems like yesterday you two littluns were haring round the place! Ahh, time flies!":
"You and Gemma, all grown-up! Seems like yesterday you two littluns were haring round the place!",
"Hello there, young {var:1}! Do you know what's good? Prayer, that's what! You should get down to the church every chance you get!":
"Hello, young {var:1}! Know what's good? Prayer! You should get down to the church every chance you get!",
"I just hope he hasn't decided to go up the Tor on his own. No, he wouldn't be that stupid, surely? Ahh, he'll be the death of me!":
"I hope he hasn't gone up the Tor on his own. No, he wouldn't be that stupid, surely? Oh, I do worry!",
"My Cole told me everything! He told me how you fought off those horrible foggy monsters! I don't know how to thank you!":
"Cole told me how you fought off those horrible foggy monsters, {var:1}! I don't know how to thank you!",
"Sorry, {var:1}. My horses don't have a lot of get-up-and-go at the minute. They're too busy enjoying this delicious grass!":
"Sorry, {var:1}. My horses have no get-up-and-go at the minute. They're too busy with this delicious grass!",
"Sorry, {var:1}. The old fellers here are busy eating their beloved grass. I don't think they'll be moving any time soon.":
"Sorry, {var:1}. The old fellers are busy eating their beloved grass. They won't be moving any time soon.",
"The symbols on the side of the Tor represent the Spirit of the Land, you know. The Spirit has always watched over Cobblestone.":
"The symbols on the Tor represent the Spirit of the Land, you know. It has always watched over Cobblestone.",
"Hey, {var:1}! You don't want to be wandering around outside the village after the day you've had! Get yourself home!":
"Hey, {var:1}! You don't want to wander outside the village after the day you've had! Get yourself home!",
"He would have been so proud to see how big and strong you've grown. Seems like only yesterday you were knee-high to a grasshopper!":
"He'd have been so proud to see how big you've grown. Seems like yesterday you were knee-high to a grasshopper!",
"And now you're off to fulfil your destiny straight after the ceremony! Come home for a rest if it all gets too much, won't you?":
"And now you're off to fulfil your destiny right after the ceremony! Come home if it all gets too much, won't you?",
"Thanks for clobbering those stupid monsters! When I grow up, I'm going to be big and tough, just like you, {var:1}!":
"Thanks for clobbering those monsters! When I grow up, I'll be big and tough, just like you, {var:1}!",
"And he says it's full of all kinds of people—way more than you see in Cobblestone. I can't wait to grow up and see it for myself!":
"And it's full of people—way more than in Cobblestone. I can't wait to grow up and see it for myself!",
"I saw your mate Gemma over by the old tree. She was lookin' a bit sorry for 'erself. Maybe you should go an' 'ave a word, eh?":
"Your mate Gemma's over by the old tree, lookin' a bit sorry for 'erself. Why not go an' 'ave a word, eh?",
"So yer leavin' us for a bit, eh? Well, they're all up at the north entrance waitin' to wave you off. We'll miss ya, sunshine!":
"So yer leavin' us, eh? They're all at the north entrance waitin' to wave you off. We'll miss ya, sunshine!",
"Word to the wise—don't go pickin' fights wiv monsters tougher than you. I did in me younger days, an' I've got the scars to prove it!":
"Word to the wise—don't pick fights wiv monsters tougher than you. I did once, an' I've got the scars to prove it!",
"It's all thanks to the Spirit of the Land that you came back from the Tor safe and sound. It watches over us all, you know.":
"It's thanks to the Spirit of the Land that you came back from the Tor safe and sound. It watches over us all.",
"Well, well—if it isn't Cobblestone's newest grown-ups! Were you looking for the Mayor? He's at home at the moment.":
"Well, if it isn't Cobblestone's newest grown-ups! Looking for the Mayor? He's at home at the moment.",
"I shouldn't say this, but he's been worried sick about you, Gemma. Only natural, I suppose—he is your grandad, after all.":
"I shouldn't say this, but he's been worried sick about you, Gemma. Only natural—he is your grandad!",
"Poor Gemma's been crying and crying! But she says she'll smile when she sees you off—oops! I wasn't meant to tell you that!":
"Poor Gemma's been crying and crying! But she'll smile when she sees you off—oops! I wasn't meant to say that!",
"May your climb teach you how truly blessed we are to live among such beautiful surroundings. We will pray for your safe return.":
"May your climb show you how blessed we are to live amid such beauty. We will pray for your safe return.",
"When the lightning struck the Tor, I must confess that I feared for your safety. But it seems that you escaped unharmed.":
"When lightning struck the Tor, I confess I feared for your safety. But it seems you escaped unharmed.",
"Ahh, I remember climbing the Tor all those years ago! Back then, I was young, single and free... Great days, great days!":
"Ahh, I remember climbing the Tor all those years ago! I was young, single and free... Great days!",
"And they say there are more of the blighters running around outside the village than ever before. I don't like this one bit.":
"And they say there are more of the blighters outside the village than ever before. I don't like it one bit.",
"Alright? Little bird told me you an' yer mate Gemma went up the Tor an' back. You ain't a little boy no more, {var:1}—yer a man!":
"Alright? I 'eard you an' Gemma went up the Tor an' back. You ain't a little boy no more, {var:1}—yer a man!",
"'Ere's some advice, from one bloke to anuvver—keep yer mind on the job! No matter 'ow fierce the fightin' gets, stay focused!":
"'Ere's some advice from one bloke to anuvver—no matter 'ow fierce the fightin' gets, stay focused!",
"Cobblestone's well tucked away here in the valley. There aren't that many people who even know this place exists, you know.":
"Cobblestone's well tucked away in this valley. Not many people even know this place exists, you know.",
"And that's why it's so lovely and safe. The monsters don't tend to bother us, and we get to live in peace and quiet. Lovely!":
"That's why it's so safe. The monsters don't bother us, and we get to live in peace and quiet. Lovely!",
"I heard all about it from your mother—she said there's an important journey you have to make. And you just a youngster!":
"Your mother told me there's an important journey you have to make. And you just a youngster!",
"I remember when you were a little boy, you know. You were always going off fishing with your grandfather. You two were inseparable!":
"When you were little, you were always off fishing with your grandfather. You two were inseparable!",
"I don't know what this big journey of yours is about, but wherever you end up, don't forget us back here in Cobblestone.":
"I don't know what this journey of yours is about, but wherever you end up, don't forget us in Cobblestone.",
"Whenever you find a spot with lovely scenery like this, take time to stop and bask in it. It does you the power of good!":
"Whenever you find lovely scenery like this, stop and bask in it. It does you the power of good!",
"Apparently, it's always bustling with people, and the shops are full of all kinds of lovely things. Not like boring old Cobblestone!":
"It's always bustling with people, and the shops are full of lovely things. Not like boring old Cobblestone!",
"So the ceremony's all done? Congratulations! Now, don't tell me you've forgotten where you live in all the excitement?":
"Ceremony done? Congratulations! Don't tell me you've forgotten where you live in all the excitement?",
"It's amazing when you think about it, isn't it? Yggdrasil, the World Tree, has watched over Erdrea since the dawn of time.":
"It's amazing, isn't it? Yggdrasil, the World Tree, has watched over Erdrea since the dawn of time.",
"They say the tree here is as old as Yggdrasil. I don't know if that's true, but there's something special about it, right enough.":
"They say this tree is as old as Yggdrasil. Who knows if that's true, but there's something special about it.",
"If you get hurt from too much fighting, you can use them to heal yourself. Wouldn't go anywhere without a couple if I were you.":
"If you get hurt in a fight, you can use them to heal yourself. I wouldn't go anywhere without a few.",
"Make sure you're never caught without medicinal herbs, you hear? They can be the difference between life and death in a pinch.":
"Never be caught without medicinal herbs, you hear? They can mean the difference between life and death.",
"I am Zeckendorf, the Vista Hunter. I roam the world's most stunning sights and paint each one onto the canvas of my heart.":
"I am Zeckendorf, the Vista Hunter. I roam the world's finest sights and paint them on the canvas of my heart.",
"But just because you agreed to help doesn't mean you have to rush. Do it when you're stuck or have time to spare.":
"But there's no need to rush a favour. Do it when you're stuck or have some time to spare.",
"My grandad's been teaching me the prayer since I was little. He reckons the Spirit of the Land really does live on the Tor, you see.":
"Grandad's taught me the prayer since I was little. He says the Spirit of the Land really lives on the Tor.",
"As long as I can remember, he's been preparing me for this day... the day I'd climb all the way up there and offer my thanks.":
"He's been preparing me for this day as long as I can remember... the day I'd climb up there and give thanks.",
"I wonder whose idea it was, sending young folk on such a dangerous errand. What if I take a tumble and do myself a mischief?":
"Whose idea was it to send young folk on such a dangerous errand? What if I take a tumble off a cliff?",
"I'll bet that's where those awful things came from. Well, as long as you're with me, I've got nothing to worry about. Come on!":
"I bet that's where those awful things came from. Well, with you here, I've nothing to worry about. Come on!",
"Never mind that now—what were you thinking!? You could've been killed! Take Sandy and get back to the village this instant!":
"What were you thinking!? You could've been killed! Take Sandy and get back to the village this instant!",
"Whoever dreamed up this ceremony must have had this in mind—they wanted to show us how huge our world really is...":
"Whoever dreamed up this ceremony must have wanted to show us how huge our world really is...",
"It was wonderful! I saw the sea stretching to the horizon, with the sunlight sparkling on the water... I've never seen anything like it!":
"It was wonderful! The sea stretched to the horizon, sparkling in the sun... I've never seen anything like it!",
"Now, it's high time we were heading back. {var:1}, go and tell your mother the ceremony's done. Don't keep her in suspense!":
"Now, it's time we headed back. {var:1}, go and tell your mother the ceremony's done. Don't keep her waiting!",
"A monster attacked us at the top of the Tor, and I ended up hanging off the cliff by my fingertips! I thought I was done for!":
"A monster attacked us at the top of the Tor, and I was left hanging off the cliff! I thought I was done for!",
"The truth is... there's something I've been keeping secret for sixteen years—something I've never told another soul in the village...":
"The truth is... for sixteen years I've kept a secret—one I've never told another soul in the village...",
"Don't ask me what a Luminary is, dear! All I know is that your grandfather always said you had a great destiny to fulfil...":
"Don't ask me what a Luminary is, dear! Your grandfather just always said you had a great destiny...",
"He said that once you came of age, you were to head north to the great kingdom of Heliodor and show that necklace to the King...":
"He said that once you came of age, you should go north to Heliodor and show that necklace to the King...",
"Well, we won't be seeing each other for a while after tomorrow! So tonight, your mother's making you the best dinner ever!":
"Well, we won't see each other for a while after tomorrow! So tonight, I'm making you the best dinner ever!",
"{var:1} tries his hardest to sleep, but he's too confused by everything he's learned, and excited about his coming trip.":
"{var:1} tries to sleep, but he's too confused by what he's learned, and too excited about his trip.",
"\"Long, long ago, the world was terrorised by monsters. But then the Luminary appeared out of nowhere and saved the day.\"":
"\"Long ago, monsters terrorised the world. But then the Luminary appeared out of nowhere and saved the day.\"",
"Why don't you visit the village shop before you head off to Heliodor? You'll need some supplies for your big adventure.":
"Visit the village shop before you head off to Heliodor. You'll need supplies for your big adventure.",
"If he finds out this is the village that raised the Luminary, there might be something in it for us, if you catch my drift.":
"If he hears we raised the Luminary, there might be something in it for us, if you catch my drift.",
"Heliodor's north of the village. There are lots of monsters out there, so be sure to keep this charm close, won't you!":
"Heliodor's north of the village. There are lots of monsters out there, so keep this charm close, won't you!",
"Oh-ho! I know a budding adventurer when I see one! Heading out without knowing the basics is risky. Let me teach you a thing or two!":
"Oh-ho! A budding adventurer! Heading out without knowing the basics is risky. Let me teach you a thing or two!",
"See the remains of that fire over there? When you spy one of those, it means you can set up camp and rest your weary bones!":
"See the remains of that fire? Wherever you spy one, you can set up camp and rest your weary bones!",
"To settle down for the night, just go up to the fire and examine it. Night will fall while you camp, so enjoy a well-earned break.":
"To camp, just examine the fire. Night falls while you're camping, so enjoy a well-earned break.",
}
