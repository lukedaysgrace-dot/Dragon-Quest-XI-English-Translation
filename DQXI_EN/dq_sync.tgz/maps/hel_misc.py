# Heliodor misc: script/a_020 & a_030 ie.bxon (field events), talk_party a020/a030 (Erik's party chat),
# region r002 (foothills chapel + Last Bastion tent nun + pep power quest). (pack, entry, off) -> (src, en)
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__))); from _paths import TOOLS, FONTS, DB, ROWS
import json
_rows = [json.loads(l) for l in open(ROWS, encoding='utf-8')]
def R(i):
    out = []
    for p in _rows[i]['pages']:
        if p.startswith('*: '): p = p[3:]
        out.append(p.replace('<pc>', '{var:1}').replace('<yesno>', '').strip())
    return ' '.join(out)
M = {}
def add(pack, entry, items):
    for off, v in items:
        if isinstance(v, int): v = ('o', R(v))
        elif isinstance(v, str): v = ('o', v)
        M[(pack, entry, off)] = v
F = lambda t: ('f', t)
add('/script/a_020.pack', 'ie.bxon', [
 (0x24c, 12099),
 (0x2c4, 12100),
 (0x364, 12101),
 (0x428, F("It looks like the mysterious young man dug this hole. Go inside?")),
 (0x520, F("Looks like the guards are on patrol... Let's not pick any pointless fights. Keep low and move carefully.")),
 (0x640, F("Which mode would you like to continue your adventure in? You can change it at any church.")),
])
add('/script/a_030.pack', 'ie.bxon', [
 (0x2c0, "These planks don't look comfortable, but there's nowhere better nearby. Bed down here for the night?"),
 (0x370, 12125), (0x4a0, 12125),
 (0x3ac, F("What's more, {var:1} is 5 gold coins lighter. Someone must have pinched them in the night!")),
 (0x594, F("Whine... Whine...")),
 (0x614, F("We took it easy and now the sun's well up. Come on, let's head for Cobblestone.")),
])
TP2, TP3 = '/param/talk_party/talk_party_a020.pack', '/param/talk_party/talk_party_a030.pack'
add(TP2, 'talk_content.bxon', [
 (0x168, F("Looks like the prophecy was right. I'm destined to help you out.")),
 (0x1ec, F("Come on, let's go. We need to scram before they realise we've escaped.")),
 (0x318, F("Phew. Who knew that bridge would collapse? Still, it saved our necks.")),
 (0x384, F("No point hanging around here. Let's find a way out.")),
])
add(TP3, 'talk_content.bxon', [
 (0x1f4, F("I don't want to doubt my old partner... but maybe Derk ran off with the Orb.")),
 (0x29c, F("...To track him down, let's start at the inn on the east side of downtown where Derk and me used to crash.")),
 (0x4e4, F("Now we know where Derk is, but to get uptown we need to get past that guard...")),
 (0x5a0, F("Word is that guard's no fan of dogs. If we borrow one, we can scare him off. Then it's on to Derk's shop by the castle!")),
 (0x6ac, F("Well, what do you know? Old Derk was looking out for me all this time. I owe him one.")),
 (0x764, F("But what did Derk mean, the Orb's all right? Let's head outside and hear what he has to say.")),
 (0x818, F("So we finally made it to the classy part of town. Let's find Derk's shop by the castle.")),
 (0x8a4, F("...But don't forget we're still Heliodor's most wanted. Let's get to the shop without the guards spotting us.")),
 (0x964, F("Thanks to Derk, we know where the Orb is. I really owe that guy.")),
 (0x9d4, F("Your hometown Cobblestone's on the way to the Kingsbarrow, right? Let's drop by while we're at it.")),
 (0xaa8, F("Right, first stop: the Manglegrove, south of Heliodor.")),
 (0xb24, F("That monster's dumb tricks really slowed us down. Come on, let's push on.")),
 (0xbe4, F("Your hometown's somewhere in the mountains of the Heliodor region. Let's drop by before the Kingsbarrow.")),
 (0xcd8, F("What was all that crazy stuff we just saw? It was like seeing something that happened right here before...")),
 (0xd94, F("...Thinking too hard isn't my style. Let's find that chest with the monster in it, and see if Rover's the woodcutter.")),
 (0xe6c, F("Let's head back the way we came and check the map for any likely spots.")),
 (0xf14, F("You can use the Fun-Size Forge at any campsite from now on. Make good use of it!")),
 (0xf98, F("Once we're through this jungle, your hometown's not far. Let's move before the guards catch up.")),
 (0x1058, F("...So this is the Manglegrove, huh?")),
 (0x10b8, F("Once we're through this jungle, your hometown's not far. Come on.")),
 (0x1148, F("Cobblestone's somewhere in the mountains south of Heliodor, right?")),
 (0x1204, F("I scoped out the area before we stole the Orb. The map showed nothing but craggy mountains. Never knew there was a village.")),
 (0x12f8, F("Well, the Orb's been returned to its rightful owner—me! Next stop, your hometown!")),
 (0x1398, F("Let's get out of here. I don't care how sacred this place is, I don't like dusty old ruins.")),
 (0x1468, F("Looks like we came to the Kingsbarrow before Cobblestone. Well, let's get my Orb back while we're here.")),
 (0x1534, F("...Still, why were the Heliodor guards that were meant to protect the Orb all out cold...?")),
 (0x169c, F("When I meet the folks from your hometown, I want to thank them first.")),
 (0x1720, F("I only escaped because you came to the castle. It's all thanks to the people of Cobblestone who raised you.")),
 (0x1800, F("Cobblestone's somewhere in the mountains south of Heliodor, right? Let's get going.")),
])
R2 = '/param/region/r002.pack'
add(R2, 'npc_ie.bxon', [
 (0x19b0, F("The escaped prisoners have yet to be caught, and no one knows where they are. It's frightening, but all I can do is...")),
 (0x1b58, F("The escaped prisoners have yet to be caught, and no one knows where they are. It's frightening, but all I can do is...")),
 (0x1adc, F("Oh, you're back. Your wounds have only just healed, so please don't push yourself too hard.")),
 (0x1c98, F("A great many soldiers passed by here a little while ago. I do hope they catch those prisoners soon... Now then.")),
 (0x1dbc, F("A great many soldiers passed by here a little while ago. I do hope they catch those prisoners soon... Now then.")),
 (0x1f2c, F("Every tent in the Bastion is full. This is the only one free, so please use it as an inn.")),
 (0x1fd4, F("I'd rather not take money, but times being what they are... Please think of it as a donation to the Bastion.")),
 (0x2138, F("There's still a little time before the battle. Don't hold back—rest up and get yourself into peak condition.")),
 (0x2294, F("Going into battle wounded is throwing your life away. Resting is part of fighting too. Now then...")),
 (0x23f8, F("So you're setting out at last... The people have been told not to see you off, lest the monsters notice.")),
 (0x24c4, F("But even without words, all our hearts are with you. We pray the plan succeeds and you return safely. Take care.")),
 (0x2628, F("I'd rather not take money from someone who fights for us, but times being what they are...")),
 (0x26e4, F("It's all because of the evil power of the monster that brought the darkness... Please think of it as a donation.")),
 (0x289c, F("Hello there. I'm a travelling merchant. It's grim all around here, but by some luck the church survived.")),
 (0x2970, F("It must be the will of the Goddess. You can still save and rest in there, so go in and recover. Now then...")),
 (0x2b54, "So that blue-haired chap is called Erik, is he? He looks like he can handle himself. You could do worse."),
 (0x2c08, F("You and Erik should be able to pull off pep powers—special moves you can only do by teaming up.")),
 (0x2cbc, F("Pep powers happen when abilities combine into something extra special. They're well worth learning.")),
 (0x2d9c, F("Let me think... You and Erik should be able to use The Real Decoy. Try taking out a monster with it.")),
 (0x2e44, F("Then you'll see how great teamwork can be. Want to give it a try while you build up some battle experience?")),
 (0x2f78, "Hmph. So you'd rather do things alone, eh? Your loss. There's nothing quite like a pep power..."),
 (0x30dc, F("That's the spirit! One word of warning, though—The Real Decoy only works if you're both pepped up.")),
 (0x319c, F("When monsters are attacking you in battle, sometimes you'll find you're fully focused. That's being pepped up.")),
 (0x3290, F("That's all I've got to say. Take out a monster with The Real Decoy, then come back and see me.")),
 (0x33f0, "You and that blue-haired chap could pull off The Real Decoy with panache! Go and try it on a hapless monster!"),
 (0x34b4, 27684),
 (0x3544, F("When monsters are attacking you in battle, sometimes you'll find you're fully focused. That's being pepped up.")),
 (0x3788, F("...No! Don't say a word! A man of my vast fighting experience can tell straight away!")),
 (0x3864, 27688),
 (0x3924, F("You took out a monster with The Real Decoy, didn't you?")),
 (0x39a0, F("Heh... So now you know how great teamwork can be. Good. I'm satisfied too.")),
 (0x3a58, F("Here, take this. It's my thanks for making an old warrior happy.")),
 (0x3ad4, F("There are lots of pep powers out there. Some combine spells with abilities, too.")),
 (0x3e94, F("There are lots of pep powers out there. Some combine spells with abilities, too.")),
 (0x3bb4, F("And I hear there are even some that need three of you pepped up at once.")),
 (0x3f74, F("And I hear there are even some that need three of you pepped up at once.")),
 (0x3c68, F("The more spells and abilities you learn, and the more friends you make, the more pep powers you'll be able to use.")),
 (0x4028, F("The more spells and abilities you learn, and the more friends you make, the more pep powers you'll be able to use.")),
 (0x3d4c, F("Don't forget, you're not alone. Fight together and you'll find a way. Look after your friends.")),
 (0x410c, F("Don't forget, you're not alone. Fight together and you'll find a way. Look after your friends.")),
 (0x4204, F("Pep powers...")),
 (0x4224, F("Teamwork is\na fine thing...")), (0x4254, F("Teamwork is\na fine thing...")),
])
