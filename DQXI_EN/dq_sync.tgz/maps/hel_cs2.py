# Heliodor a_030 cutscenes (chapel, Erik joins, camp/forge, woodlands bridge, Downtown, Derk)
# (pack, entry, off) -> (src, english). Official lines are pulled by row index from the
# official script (Cutscenes - Act 1) so nothing is retyped; 'f' entries are fan text for
# lines that differ on 3DS.
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__))); from _paths import TOOLS, FONTS, DB, ROWS
import json
P = '/param/scenario/cs/%s.pack'
_rows = [json.loads(l) for l in open(ROWS, encoding='utf-8')]
A = [r for r in _rows if r['file'] == 'Cutscenes - Act 1']
def off_text(i):
    out = []
    for p in A[i]['pages']:
        if p.startswith('*: '): p = p[3:]
        out.append(p.replace('<pc>', '{var:1}').replace('<yesno>', ''))
    return '\n'.join(out)
M = {}
def add(pack, items):
    for off, v in items:
        if isinstance(v, int): M[(P % pack, 'cs_text.bxon', off)] = ('o', off_text(v))
        elif isinstance(v, tuple): M[(P % pack, 'cs_text.bxon', off)] = v
        else: M[(P % pack, 'cs_text.bxon', off)] = ('o', v)
TD, FL, DK = 'Tricky Devil', 'Flint', 'Derk'
add('a_030_cs_010', [(0x104, ('f', "...ake up... {var:1}...")), (0x11c, 244), (0x154, 245), (0x224, 246),
                     (0x2e8, 247), (0x3d8, 248)])
add('a_030_cs_020', [(0x174, 250), (0x1fc, 251), (0x248, 252), (0x2f4, 253), (0x3dc, 254), (0x460, 255),
                     (0x554, 256), (0x678, 257), (0x6c4, 258), (0x7ac, 259)])
add('a_030_cs_030', [(0x19c, 261), (0x270, 262), (0x34c, 263), (0x3e4, 264), (0x464, 265), (0x54c, 266),
                     (0x5d4, 267), (0x6b4, 268), (0x768, 269), (0x82c, 270), (0x8d4, 271)])
add('a_030_cs_031', [(0x1f0, 273), (0x2b0, 274), (0x380, 275), (0x450, 276), (0x508, 277), (0x5dc, 278),
                     (0x698, 279), (0x794, 280), (0x864, 281), (0x924, 282), (0x9c4, 283),
                     (0xa2c, ('f', "Learned how to make bronze swords!\nLearned how to make divine daggers!")),
                     (0xaa0, 285),
                     (0xbac, ('f', "From now on, you can use the Fun-Size Forge whenever you rest at a campsite. "
                                   "Any time you feel like forging, head for a camp."))])
add('a_030_cs_032', [(0x254, 286), (0x2fc, 287), (0x314, 288), (0x3c0, 289), (0x400, TD), (0x414, 290),
                     (0x4a4, 291), (0x4c0, 292), (0x4d4, TD), (0x4e8, 293), (0x584, TD), (0x598, 294),
                     (0x5e8, TD), (0x5fc, 295), (0x6c4, 296), (0x768, 297), (0x78c, 298), (0x7ec, 299),
                     (0x8b0, 300),
                     (0x938, ('f', "And if what we just saw was true, Rover here might be the woodcutter who can fix that bridge.")),
                     (0x9e8, ('f', "There's only one way to find out! That chest with the monster in it was down by the river. "
                                   "Let's head back the way we came and have a word with our mischievous friend!")),
                     (0xae4, ('f', "If what we just saw was true, Rover here might be the woodcutter who can fix that bridge. "
                                   "Why don't we find that chest and see for ourselves?")),
                     (0xbf4, ('f', "If I remember right, there was a waterfall near that chest. I heard one off to the west "
                                   "on our way here, so let's try there first!"))])
add('a_030_cs_034', [(0xe8, 303), (0x11c, TD), (0x130, 304), (0x198, 305), (0x1b4, TD), (0x1c8, 306),
                     (0x244, 307), (0x29c, TD), (0x2b0, 308)])
add('a_030_cs_036', [(0x2e0, TD), (0x2f4, 309), (0x314, TD), (0x328, 310), (0x358, 311),
                     (0x3a0, ('f', "Wait... Don't tell me you're that mutt?")), (0x3cc, 313),
                     (0x45c, FL), (0x46c, 314), (0x51c, 315), (0x5d4, FL), (0x5e4, 316), (0x69c, 317),
                     (0x710, FL), (0x720, 318), (0x7f8, 319), (0x85c, FL), (0x86c, 320), (0x91c, FL), (0x92c, 321),
                     (0x9c0, ('f', "The Guidance of Yggdrasil...?")), (0xa04, FL), (0xa14, 323), (0xab8, FL), (0xac8, 324),
                     (0xb74, FL), (0xb84, 325), (0xc64, FL), (0xc74, 326), (0xd40, FL), (0xd50, 327),
                     (0xdd4, FL), (0xde4, 328), (0xe74, FL), (0xe84, 329), (0xf54, FL), (0xf64, 330),
                     (0x1028, 331), (0x10b8, ('f', "Well, whatever. Let's get moving, {var:1}."))])
add('a_030_cs_040', [(0xf4, 333), (0x1dc, 334), (0x2cc, 335), (0x3b4, 336), (0x4a4, 337)])
add('a_030_cs_050', [(0x148, 339), (0x1fc, 340), (0x258, ('f', "...")), (0x290, 342), (0x2bc, 343),
                     (0x354, 344), (0x3c4, 345), (0x428, 346)])
add('a_030_cs_055', [(0xf4, 348), (0x1b8, 349), (0x240, 350), (0x2e8, 351),
                     (0x39c, ('f', "So here's the plan—there's a tower on the east side of town they use to look out for fires. "
                                   "You climb up there and keep an eye out for Ruby.")), (0x430, 353)])
add('a_030_cs_060', [(0x84, 354), (0x108, 355)])
add('a_030_cs_070', [(0x1b8, 356), (0x1e8, 357), (0x238, 358), (0x2c0, 359), (0x334, 360), (0x3b8, 361),
                     (0x414, 362), (0x47c, 363), (0x4fc, 364), (0x5e4, 365), (0x6c4, 366), (0x704, 367), (0x7fc, 368)])
add('a_030_cs_080', [(0xa0, 369),
                     (0x174, ('f', "Uptown's past that gate. We could always grease the sentry's palm... "
                                   "but I'd rather not throw money around before we hit the road.")),
                     (0x28c, ('f', "Wait, isn't he...? Yeah, I remember hearing that guard is terrified of dogs. "
                                   "Let's borrow one off somebody and get past him. Then it's on to Derk's shop, up by the castle!"))])
add('a_030_cs_083', [(0xcc, 372), (0x190, 373), (0x1a4, 374), (0x214, 375), (0x2c8, 376)])
add('a_030_cs_085', [(0x174, 377), (0x244, 378), (0x2c4, 379), (0x30c, 380), (0x364, 381), (0x430, 382),
                     (0x504, 383), (0x5e8, ('f', "Roxy!? A-A-A-As in, THE Roxy!? In love with...with me!?")),
                     (0x618, 385), (0x6c4, 386)])
add('a_030_cs_087', [(0xcc, 388), (0x118, 389), (0x164, 390), (0x224, 391), (0x2c8, 392)])
add('a_030_cs_090', [(0x27c, 393), (0x2bc, 394), (0x354, 395), (0x3c8, 396), (0x3f0, 397), (0x414, DK),
                     (0x420, 398), (0x4d8, 399), (0x538, 400), (0x600, DK), (0x60c, 401), (0x6e0, 402),
                     (0x790, DK), (0x79c, 403), (0x828, DK), (0x834, 404), (0x8f8, DK), (0x904, 405),
                     (0x9d8, DK), (0x9e4, 406), (0xac8, 407), (0xb98, DK), (0xba4, 408), (0xc44, 409),
                     (0xcc4, DK), (0xcd0, 410), (0xd0c, 411), (0xd54, DK), (0xd60, 412)])
add('a_030_cs_100', [(0x20c, 413), (0x270, DK), (0x27c, 414), (0x364, DK), (0x370, 415), (0x42c, 416),
                     (0x468, 417), (0x530, 418), (0x5fc, DK), (0x608, 419), (0x6cc, 420), (0x78c, 421),
                     (0x824, DK), (0x830, 422), (0x8b4, 423), (0x990, 424), (0xa64, 425), (0xaec, DK),
                     (0xaf8, 426), (0xb54, DK), (0xb60, 427)])

# condensed versions of official lines that do not fit the 3-line window (still 'o': official wording, trimmed)
TRIM = {
 ('a_030_cs_031', 0xbac): ('f', "From now on, you can use the Fun-Size Forge whenever you're at a campsite. Fancy some forging? Head for a camp."),
 ('a_030_cs_032', 0x9e8): ('f', "Only one way to find out! That chest with the monster was by the river. Let's go back and have a word with our friend!"),
 ('a_030_cs_032', 0xae4): ('f', "If what we saw was true, Rover here's the woodcutter who can fix that bridge. Let's find that chest and see for ourselves."),
 ('a_030_cs_055', 0x39c): ('f', "Here's the plan—climb the fire lookout tower on the east side of town and keep an eye out for Ruby."),
 ('a_030_cs_080', 0x174): ('f', "Uptown's past that gate. We could grease the sentry's palm... but I'd rather not waste money before we hit the road."),
 ('a_030_cs_080', 0x28c): ('f', "Wait, isn't that guard terrified of dogs? Let's borrow one off somebody and get past him. Then it's on to Derk's shop!"),
 ('a_030_cs_010', 0x154): "Finally! I was worried we'd lost you there. You've been out cold ever since we jumped. Had to drag you here on my own.",
 ('a_030_cs_020', 0x2f4): "It seems some dangerous criminals have escaped from the capital and are at large in the area. Oh, I shudder to think...",
 ('a_030_cs_020', 0x554): "And they say Sir Hendrik has gone south with his troops to block the road to Cobblestone, the fugitives' village.",
 ('a_030_cs_030', 0x19c): "Cobblestone, eh? Never heard of it. I didn't even know anyone lived in those mountains down south. That's where you're from?",
 ('a_030_cs_030', 0x270): "I'm guessing you want to go see what's happening there, but be smart—you won't get past Hendrik unnoticed.",
 ('a_030_cs_030', 0x464): "But I've got things to take care of in Heliodor first. I left a little something in one of my old haunts downtown.",
 ('a_030_cs_030', 0x5d4): "Come on, don't be like that! I just need to pop back to town and grab it. Then I'll show you the scenic route to Cobblestone.",
 ('a_030_cs_030', 0x82c): "Heh! That's more like it! If you're going to be a wanted man, you might as well look the part! Right, let's head north!",
 ('a_030_cs_031', 0x2b0): "I still can't get over old Derk. Married, a shop in the best part of town... He went straighter than straight.",
 ('a_030_cs_031', 0x5dc): "Behold...the Fun-Size Forge! Pop materials on top, bash 'em with the Portapounder and Bob's your uncle!",
 ('a_030_cs_031', 0xaa0): "Recipes are hidden all over—chests and bookshelves are a good bet. Keep an eye out and you'll find some beauties!",
 ('a_030_cs_032', 0x314): "I repaired the bridge only yesterday, and some blighter's gone and wrecked it again! If I ever find who did this, I'll—",
 ('a_030_cs_032', 0x414): "I went to a lot of trouble to smash this bridge! I'm not letting you fix it! Get a load of my devilishly tricky shape-shift beam!",
 ('a_030_cs_032', 0x4e8): "Koo hoo! Now that's tricky! One minute a silly old woodcutter, the next a smelly old dog! I'm a devilish genius!",
 ('a_030_cs_034', 0x2b0): "What did you just s—!? Grr! Cheeky devil! I'll teach you! For my next trick, I'm going to beat you to a pulp!",
 ('a_030_cs_036', 0xb84): "The legends say each of its leaves represents a life, and its power preserves the peace and harmony of our realm.",
 ('a_030_cs_036', 0xe84): "Heh heh! It's all coming back now! As a boy, I'd spend hours talking to the silly old thing, but did anything happen? Not a bit!",
 ('a_030_cs_036', 0xf64): "But you, young man, you're special—chosen by the World Tree. And you've got great hair too. Life isn't fair...",
 ('a_030_cs_040', 0x1dc): "A year ago, me and my partner in crime Derk managed to...acquire the royal family's most precious treasure—the Red Orb.",
 ('a_030_cs_055', 0xf4): "Heh! This old place hasn't changed a bit! Back in our thieving days, Derk and me used to lay low here.",
 ('a_030_cs_070', 0x704): "Look, round 'ere you don't go askin' too many questions, you know that. If you want more, get it from the 'orse's mouth.",
 ('a_030_cs_080', 0xa0): "That no-good traitor! He sold me out and sold the Orb so he could move up in the world! Well, I'll get what I'm owed!",
 ('a_030_cs_083', 0xcc): "Halt! This gate leads to the nice part of town. My job is to keep out rabble and riff-raff. In other words, you!",
 ('a_030_cs_085', 0x174): "Halt! This gate leads to the nice part of town. My job is to keep out rabble and riff-raff. In other words, you!",
 ('a_030_cs_085', 0x364): "'Forgive me for being so forward, but I cannot hide my feelings any longer. When I think of you, my heart goes pitter-patter.",
 ('a_030_cs_085', 0x430): "I need to see you. I am waiting for you in the town square.\n         Eternally yours, your Dancing Darling.'",
 ('a_030_cs_085', 0x504): "A beautiful girl asked us to give you this. What was her name again? Roxy, I think. She's waiting for you in the square.",
 ('a_030_cs_085', 0x618): "I can't be standing here on sentry duty! My duty is to be beside my darling! When love calls, one must answer!",
 ('a_030_cs_090', 0x420): "E-E-Erik! My b-brother...my partner in crime! It's really—Urgh!—you, fightin' fit! I'm so—Ngh!—'appy to see you!",
 ('a_030_cs_090', 0x538): "You always were full of it, Derk. Admit it—you sold me out and sold the Orb so you could buy this place, didn't you?",
 ('a_030_cs_090', 0x79c): "Look, I was never much of a thief—you know that. But turns out I know 'ow to sell stuff. I got the gift!",
 ('a_030_cs_090', 0x834): "When you got nabbed, I spent months rackin' me brains for ways of bustin' you out. I couldn't stand it.",
 ('a_030_cs_090', 0x9e4): "Then I used the cash to open the shop, and poured me profits into bribin' the castle guards so they'd let you escape.",
 ('a_030_cs_100', 0x27c): "After I 'anded over the Orb, I kept me ear to the ground about where it ended up. I knew it was important to you, see.",
 ('a_030_cs_100', 0x6cc): "Married? Wow, you really have changed. Well, you always said you wanted to go into business some day. I'm happy for you.",
 ('a_030_cs_100', 0x8b4): "The south gate is crawling with guards, so that's out. And Hendrik's men are too uptight to take bribes...",
 ('a_030_cs_100', 0x990): "We'll have to go the long way round. If we skirt the hills to the south, we can reach the Kingsbarrow from the other side.",
}
for (pk, off), v in TRIM.items():
    M[(P % pk, 'cs_text.bxon', off)] = v if isinstance(v, tuple) else ('o', v)
