# Quest titles (quest_param) and quest log texts (quest_ui_param) for the Cobblestone/Heliodor quests.
# Official quest names/descriptions ('Misc - Quest Text') adapted to the 3DS quest structure; the log texts are
# wrapped here to the Japanese line width (the quest window does not wrap by itself).
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__))); from _paths import TOOLS, FONTS, DB, ROWS
import sys, re, sqlite3
sys.path.insert(0, TOOLS)
import wrap
_m = wrap.Metrics(FONTS)
_db = sqlite3.connect(DB)
Q, QU = ('/gamecmn.pack', 'quest_param.bxon'), ('/gamecmn.pack', 'quest_ui_param.bxon')
M = {}
def _fit(off, text):
    jp = _db.execute('select jp from strings where id=?', ('%s|%s|%x' % (QU + (off,)),)).fetchone()[0]
    specs, maxl = wrap.adaptive_specs(_m, jp)
    lines = wrap.wrap(_m, text, [(f, px) for f, px in specs])
    # adaptive check runs unscaled
    lines = []
    for para in text.split('\n'):
        cur = ''
        for w in para.split(' '):
            c = w if not cur else cur + ' ' + w
            if not cur or wrap.fits(_m, c, specs, 1.0): cur = c
            else: lines.append(cur); cur = w
        lines.append(cur)
    if len(lines) > maxl: print('TOO LONG %d>%d %x: %s' % (len(lines), maxl, off, ' / '.join(lines)))
    return '\n'.join(lines)
def title(off, src, t): M[Q + (off,)] = (src, t)
def log(src, items):
    for off, t in items: M[QU + (off,)] = (src, _fit(off, t))

title(0xcd8, 'o', "The People's Friend")
title(0xcf0, "o", "Soldier and Strategist")
title(0xd38, 'o', "Amelia's in a Pickle!")
title(0xd5c, 'o', "It Takes Two to Tango")
title(0x1640, 'o', "Might Is Right!")
title(0x1678, "o", "Mistress Bev's Prediction")
title(0x16a8, 'o', "Now You See Me...")

log('o', [
 (0x16b0, "A man in Cobblestone wants you to retrieve his son's flurry feather."),
 (0x1708, "A man near the item shop in Cobblestone needs help. Go and talk to him!"),
 (0x1764, "A man in Cobblestone wants you to retrieve his son's flurry feather. Check the 2D screen and look west of the item shop."),
 (0x1804, "A man in Cobblestone wants you to retrieve his son's flurry feather. Check the 2D screen and look west of the item shop."),
 (0x18a4, "You returned the flurry feather to the man in Cobblestone. Help anyone you meet with a purple speech bubble!"),
 (0x1948, "Quest 'The People's Friend' complete!"),
 (0x19b8, "A tourist in Heliodor wants you to find a book about Sir Hendrik and Sir Jasper."),
 (0x1a38, "There's a tourist near the central stairs in Heliodor who needs help. Try talking to him!"),
 (0x1a9c, "A tourist in Heliodor wants you to find a book about Sir Hendrik and Sir Jasper. Look for bookshelves with red books in the east of town."),
 (0x1b54, "You found the book about Hendrik and Jasper! Go back and tell the tourist in Heliodor what it says!"),
 (0x1bd4, "You told the tourist in Heliodor all about Hendrik and Jasper. Leaf through any red books you find for intriguing titbits!"),
 (0x1c84, "You found the book about the two heroes! Go and tell the tourist in Heliodor!"),
 (0x1d60, "A girl in Heliodor wants you to rescue Amelia, who's stuck up on the rooftops."),
 (0x1dc8, "There's a girl near the inn in Heliodor who needs help. Try talking to her!"),
 (0x1e2c, "A girl in Heliodor wants you to rescue Amelia from the rooftops. Find a way up there and save her!"),
 (0x1ecc, "You rescued Amelia the cat from the roof! Go and tell the girl near the inn in Heliodor!"),
 (0x1f48, "You told the girl in Heliodor that you rescued Amelia from the roof. Her face lit up with joy!"),
 (0x1fec, "You helped the little girl's cat! Go and tell her the good news!"),
 (0x2094, "A warrior at the Foothills church wants you to beat a monster with The Real Decoy."),
 (0x2108, "A warrior stands at the church in the Foothills. Talk to him!"),
 (0x2160, "A warrior at the church wants you to beat a monster with The Real Decoy. It can be used when you and Erik are pepped up."),
 (0x21f8, "You beat a monster with The Real Decoy! Go and tell the warrior at the church in the Heliodorian Foothills!"),
 (0x2274, "You told the warrior about your Real Decoy victory. The more abilities you learn, the more pep powers you can use!"),
 (0x231c, "You beat a monster with The Real Decoy! Go and tell the warrior at the church in the Foothills!"),
 (0xc4a8, "An old man in Heliodor wants you to defeat Harmachis on a plateau in the south of the Hotto Steppe."),
 (0xc538, "An old man in the square before Heliodor Castle needs help. Talk to him!"),
 (0xc598, "An old man in Heliodor wants you to defeat Harmachis in the Hotto Steppe. Beat lots of bilhaws to lure him out."),
 (0xc644, "You defeated Harmachis! Go and tell the old man in the castle square in Heliodor!"),
 (0xc6a8, "You told the old man about Harmachis. It seems he was once a great general of Zwaardsrust who became a monster in death."),
 (0xc758, "You defeated Harmachis! Go and tell the old man in the castle square in Heliodor!"),
 (0xc82c, "Mistress Bev in downtown Heliodor wants you to get her some divine dew."),
 (0xc8a8, "Mistress Bev in downtown Heliodor is looking for {var:1}. Go and talk to her!"),
 (0xc908, "Mistress Bev wants some divine dew. According to her crystal ball, it can be found by a waterfall in the First Forest."),
 (0xc9ac, "You got divine dew in the First Forest! Take it to Mistress Bev downtown!"),
 (0xca08, "You gave the divine dew to Mistress Bev, but she gave it back after foreseeing her doom. She'll find another way to make money."),
 (0xcac0, "{var:1} got some divine dew! Take it to Mistress Bev in downtown Heliodor!"),
 (0xcb7c, "A boy in downtown Heliodor wants you to learn the secrets of hide-and-seek from a legendary master."),
 (0xcbf4, "A boy is hiding in downtown Heliodor. Find him!"),
 (0xcc50, "A boy in downtown Heliodor wants you to find a hide-and-seek legend. Try asking at the orphanage in Octagonia."),
 (0xccf0, "The hide-and-seek legend was Xero the Shadow! Go and tell the boy in downtown Heliodor what you've learned!"),
 (0xcd8c, "You told the boy Xero's secret of hide-and-seek: the most important thing is to have fun with your friends."),
 (0xce34, "Xero told you the secret of hide-and-seek! Go and tell the boy in downtown Heliodor!"),
])
