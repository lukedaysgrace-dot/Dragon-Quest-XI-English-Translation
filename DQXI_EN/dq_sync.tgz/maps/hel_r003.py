# Manglegrove (r003) and Kingsbarrow surroundings (r004, early part): npc_ie / book_ie
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__))); from _paths import TOOLS, FONTS, DB, ROWS
import json
_rows = [json.loads(l) for l in open(ROWS, encoding='utf-8')]
def R(i):
    out = []
    for p in _rows[i]['pages']:
        if p.startswith('*: '): p = p[3:]
        out.append(p.replace('<pc>', '{var:1}').replace('<yesno>', '').strip())
    return ' '.join(out)
F = lambda t: ('f', t)
M = {}
def add(pack, entry, items):
    for off, v in items:
        if isinstance(v, int): v = ('o', R(v))
        elif isinstance(v, str): v = ('o', v)
        M[('/param/region/%s.pack' % pack, entry, off)] = v
add('r003', 'book_ie.bxon', [
 (0x73c, F("Would you look at that... The bridge is smashed to pieces. There's no way we can cross it like this.")),
 (0x7d4, 12475),
 (0xc20, F("BRIDGE COLLAPSED - NO ENTRY\nTurn back and look for the vines")),
 (0x1810, F("Hey. Do you sense something weird coming from the path by that cabin? Let's take a look.")),
 (0x1990, F("The mark on {var:1}'s hand seems to be reacting to the curiously shaped root. Hold your hand out to it?")),
 (0x1aa4, F("The curious power has gone from this root.")),
 (0x1b2c, F("The World Tree's root grows quietly from the ground. Nothing seems to happen.")),
 (0x1c60, F("Use the Fun-Size Forge there to make the gear from the recipes I gave you. Go on, try making something!")),
 (0x1d74, F("...So, your first forging session's done. Nice. Did it go well?")),
 (0x1e1c, 12467),
 (0x1f14, F("Seriously? On your first try? Nice one, {var:1}! With practice, you'll get even better!")),
 (0x201c, F("Hey, I gave you all those materials! Aren't you going to try some forging? Make the gear from those recipes!")),
])
add('r003', 'npc_ie.bxon', [
 (0x17dc, 'Flint'), (0x18a0, 'Flint'), (0x1950, 'Flint'),
 (0x17ec, 12479), (0x18b0, F("I'm sure the World Tree's roots will guide you down the right path.")),
 (0x1960, F("After all, you're one of the special ones—chosen by the World Tree. And that silky hair, too!")),
 (0x1a30, 12472),
 (0x1acc, F("I travel all over, selling my wares. Meeting you here must be fate! Please, have a look. Now...")),
 (0x1c14, 12464),
 (0x1d4c, F("Welcome. I pay good money for well-made gear from the Fun-Size Forge. Now then...")),
])
add('r004', 'npc_ie.bxon', [
 (0x1784, 12492), (0x1834, 12492), (0x18e4, 12492), (0x1994, 12492), (0x4114, 12492),
 (0x41fc, 12497), (0x4290, 12498), (0x42ec, 12499),
 (0x1b04, 12500), (0x1bf8, 12501), (0x1cb4, F("The Kingsbarrow's just west of here. Mind how you go, sonny!")), (0x1d98, 12503),
 (0x1eb0, F("Eh? The Door of Departure? Dunno about grand, but there's an old shrine east of here.")),
 (0x1f80, F("Wanting to go to a place like that? You're an odd one, sonny.")),
 (0x203c, F("Word is an escaped prisoner stole the King's treasure from the Kingsbarrow. It's not safe round here these days.")),
 (0x2134, F("Unless you've got proper business, I'd stop wandering round here and go somewhere else.")),
])
add('r004', 'book_ie.bxon', [
 (0x9bc, 12504), (0xa30, 12505),
 (0xca8, F("Sorry, {var:1}, but before we head to the Door of Departure, I need to take care of my own business.")),
 (0xd48, F("We're going to get the Red Orb they moved to the Kingsbarrow.")),
])
